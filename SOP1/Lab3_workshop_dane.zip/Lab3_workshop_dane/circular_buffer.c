#include "circular_buffer.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

circular_buffer* circular_buffer_init() {
    // TODO
}

void circular_buffer_deinit(circular_buffer *buffer) {
    // TODO
}

void circular_buffer_enqueue(circular_buffer *buffer, const char *item) {
    // TODO
}

char* circular_buffer_dequeue(circular_buffer *buffer) {
    // TODO
}
